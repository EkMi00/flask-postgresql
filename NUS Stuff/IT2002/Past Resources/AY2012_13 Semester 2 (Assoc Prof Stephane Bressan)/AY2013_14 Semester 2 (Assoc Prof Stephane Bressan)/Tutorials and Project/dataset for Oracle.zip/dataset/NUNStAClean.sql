/*******************

  Cleaning script


*******************/

DROP TABLE loan;
DROP TABLE copy;
DROP TABLE student;
DROP TABLE book;