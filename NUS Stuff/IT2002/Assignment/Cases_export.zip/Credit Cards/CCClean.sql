/*******************

  Cleaning script

*******************/

DROP TABLE IF EXISTS transactions;
DROP TABLE IF EXISTS merchants;
DROP TABLE IF EXISTS credit_cards;
DROP TABLE IF EXISTS customers;

